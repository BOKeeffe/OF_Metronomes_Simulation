#include "ofApp.h"

/**
	@file 		ofApp.cpp
	@author		Willaim O'Keeffe
	*/


using namespace YAMPE; using namespace P;

//--------------------------------------------------------------
void ofApp::setup() {
    
    ofSetVerticalSync(true);
    
    // repatable randomness
    ofSeedRandom(10);
    
    // create a minimal gui
    gui.setup("Metronomes2");
    
    cameraHeightRatio.addListener(this, &ofApp::cameraHeightRatioChanged);
    guiParameters.setName("GUI");
    guiParameters.add(isGuiVisible.set("GUI visible", true));
    guiParameters.add(isDebugVisible.set("Debug visible", true));
    guiParameters.add(isAxisVisible.set("Unit vectors", true));
    guiParameters.add(isXGridVisible.set("Grid (X-axis)", false));
    guiParameters.add(isYGridVisible.set("Grid (Y-axis)", true));
    guiParameters.add(isZGridVisible.set("Grid (Z-axis)", false));
    guiParameters.add(isGroundVisible.set("Ground", true));
    guiParameters.add(Spring.set("Set Spring", false));
    guiParameters.add(amtOfPendulem.set("Amount of Pendulems",0.5 ,0, 200));
    resetButton.addListener(this, &ofApp::reset);
    guiParameters.add(cameraHeightRatio.set("Camera (height)", 0.1f, 0., 0.999f));
    
    gui.ofxGuiGroup::add(guiParameters);
    gui.add(resetButton.setup("Reset"));
    
    // simulation specific stuff goes here
    
    // load gui parameters from file
    gui.loadFromFile("settings.xml");
    
    // instantiate the ground
    ground.set(RANGE, RANGE);
    ground.rotate(90, 1,0,0);
    
    // lift camera to 'eye' level
    easyCam.setDistance(RANGE);
    float d = easyCam.getDistance();
    easyCam.setPosition(0, cameraHeightRatio*d, d*sqrt(1.0f-cameraHeightRatio*cameraHeightRatio));
    easyCam.setTarget(ofVec3f::zero());
    
    font.load(OF_TTF_SANS, 9, true, true);
    
    // simulation specific stuff goes here
    
    isForceVisible = false;
    
    contacts = ContactRegistry::Ref(new ContactRegistry(100, "All contacts"));

    // debug GUI
    
    // build text debug page
    debugTextPage.setup("Text");
    debugString = "";
    debugTextPage.add(&debugStringLabel);
    
    // build text debug page (using a panel to allow for multiple graphs)
    debugGraphicsPage.setup("Graphics");
    
    debugGraphicsPanel.setup("TODO");
    debugGraphicsPage.add(&debugGraphicsPanel);
    
    // finally build tabbed pages
    debugPages.setup("Debug", "", debugTextPage.getShape().getRight()+10);
    debugPages.setSize(500, 300);
    debugPages.add(&debugTextPage);
    debugPages.add(&debugGraphicsPage);
    
    // set position of debug GUI to bottom left corner
    debugPages.setPosition(0, ofGetHeight()-debugPages.getHeight());
    
}


void ofApp::reset() {
    
    // simulation specific stuff goes here
    particles.clear();
    constraints.clear();
    forceGenerators.clear();
    ppContactGenerators.particles.clear();
    
    int number = 5;
    float angle = 90 ;
    float angRad = (angle+90) * (M_PI / 180.0f);
    float start =  -RANGE/2;
    float radius = 0.2 ;
    float wireLenght = 2;
    float anchorLenght = 5;
    float restitution = 1.0f ;
    
    ofVec3f position = ofVec3f(wireLenght * (cos(angRad)), wireLenght * (sin(angRad)), 0);
    
     ForceGenerator::Ref gravity(new GravityForceGenerator(ofVec3f(0,-1,0)));
    
    for (int i = 0; i < amtOfPendulem; ++i){
        
        Particle::Ref p = Particle::Ref(new Particle());
        Particle::Ref p2 = Particle::Ref(new Particle());
        ofVec3f anchor = ofVec3f(start, 5, 0);
        ofVec3f anchorTop = ofVec3f(start, 5, 0);
        
        if(i < amtOfPendulem)
        {
            (*p).position = (anchor);
            (*p).setBodyColor(ofColor::blue)
            .setWireColor(ofColor::blue);
            
            (*p2).position = (anchor+position);
            (*p2).setBodyColor(ofColor::red)
            .setWireColor(ofColor::red);
        }
        else
        {
            (*p).position = ofVec3f(start, 1,0);
            (*p2).position = ofVec3f(start, 1,0);
        }
        
        //particle 1 anchored
        equalityAnchoredConstraints = EqualityAnchoredConstraint(p,ofVec3f((*p).position.x,(*p).position.y-wireLenght,0),wireLenght, restitution);
        equalityConstraints = EqualityConstraint(p,p, wireLenght, 0.0f);
        particles.push_back(p);
        forceGenerators.add(p, gravity);
        groundContactGenerators.particles.push_back(p);
        anchoredConstraints.push_back(equalityAnchoredConstraints) ;
        ppContactGenerators.particles.push_back(p);
        
        //particle 2
        //float distanceHorizontal = (*p).position.distance((*p2).position);
        equalityConstraints = EqualityConstraint(p,p2, wireLenght, 0.0f);
        particles.push_back(p2);
        constraints.push_back(equalityConstraints) ;
        forceGenerators.add(p2, gravity);
        groundContactGenerators.particles.push_back(p2);
        ppContactGenerators.particles.push_back(p2);
        
        start += (radius*2) + 0.000001f  ;
    }

}

void ofApp::update() {
    
    float dt = ofClamp(ofGetLastFrameTime(), 0.01, 0.02);
    
    // simulation specific stuff goes here
    forceGenerators.applyForce(dt);
    
    // update all particles
    foreach (p, particles) (*p)->integrate(dt);
    foreach(c, constraints)  (*c).generate(contacts);
    
    groundContactGenerators.generate(contacts);
    ppContactGenerators.generate(contacts);
    //equalityConstraints.generate(contacts);
    //equalityAnchoredConstraints.generate(contacts);
    contacts->resolve(dt);
    contacts->clear();
}


void ofApp::draw() {
    
    ofEnableDepthTest();
    ofBackgroundGradient(ofColor(128), ofColor(0), OF_GRADIENT_BAR);
    
    ofPushStyle();
    easyCam.begin();
    
    ofDrawGrid(RANGE/(2*8), 8, false, isXGridVisible, isYGridVisible, isZGridVisible);
    
    if (isAxisVisible) ofDrawAxis(1);
    
    if (isGroundVisible) {
        ofPushStyle();
        ofSetHexColor(0xB87333);
        ground.draw();
        ofPopStyle();
    }
    
    // simulation specific stuff goes here
    foreach(p, particles) (**p).draw();
    
    int count = 0;
    foreach(c, constraints){
        if (count < amtOfPendulem) {
            
            ofPushStyle() ;
            ofSetColor(ofColor::blue) ;
            ofDrawArrow(c->anchor,c->a->position ,0.01) ;
            ofPopStyle();
            count++;
        }else{
            ofPushStyle() ;
            ofSetColor(ofColor::red) ;
            ofDrawArrow(c->anchor,c->a->position ,0.01) ;
            ofPopStyle() ;
            count ++ ;
        }
    }
    
    easyCam.end();
    ofPopStyle();
    
    // finally render any GUI/HUD
    ofDisableDepthTest();
    if (isGuiVisible) gui.draw();
    if (isDebugVisible) {
        
        debugStringLabel.setup("",
                               "FPS = " + ofToString((int)ofGetFrameRate()) + "\n\n" + debugString);
        debugPages.draw();
    }

    
}


//--------------------------------------------------------------
// GUI events and listeners
//--------------------------------------------------------------

void ofApp::keyPressed(int key) {
    
    float d = easyCam.getDistance();
    
    switch (key) {
            
        case 'h':                               // toggle GUI/HUD
            isGuiVisible = !isGuiVisible;
            break;
        case 'b':                               // toggle debug
            isDebugVisible = !isDebugVisible;
            break;
        case 'a':                               // toggle axis unit vectors
            isAxisVisible = !isAxisVisible;
            break;
        case '1':                               // toggle grids (X)
            isXGridVisible = !isXGridVisible;
            break;
        case '2':                               // toggle grids (Y)
            isYGridVisible = !isYGridVisible;
            break;
        case '3':                               // toggle grids (Z)
            isZGridVisible = !isZGridVisible;
            break;
        case 'g':                               // toggle ground
            isGroundVisible = !isGroundVisible;
            break;
        case 'u':                               // set the up vecetor to be up (ground to be level)
            easyCam.setTarget(ofVec3f::zero());
            break;
            
        case 'S' :                              // save gui parameters to file
            gui.saveToFile("settings.xml");
            
            break;
        case 'L' :                              // load gui parameters
            gui.loadFromFile("settings.xml");
            break;
            
        case 'z':
            easyCam.setPosition(0, cameraHeightRatio*d,
                                d*sqrt(1.0f-cameraHeightRatio*cameraHeightRatio));
            easyCam.setTarget(ofVec3f::zero());
            break;
        case 'Z':
            easyCam.setPosition(0, 0, d);
            easyCam.setTarget(ofVec3f::zero());
            break;
        case 'x':
            easyCam.setPosition(d*sqrt(1.0f-cameraHeightRatio*cameraHeightRatio), cameraHeightRatio*d, 0);
            easyCam.setTarget(ofVec3f::zero());
            break;
        case 'X':
            easyCam.setPosition(d, 0, 0);
            easyCam.setTarget(ofVec3f::zero());
            break;
        case 'Y':
            easyCam.setPosition(0.001, d, 0);
            easyCam.setTarget(ofVec3f::zero());
            break;
            
        case 'f':                               // toggle fullscreen
            // BUG: window size is not preserved
            isFullScreen = !isFullScreen;
            if (isFullScreen) {
                ofSetFullscreen(false);
            } else {
                ofSetFullscreen(true);
            }
            break;
            
            // simulation specific stuff goes here
            
    }
}

void ofApp::cameraHeightRatioChanged(float & cameraHeightRatio) {
    
    float d = easyCam.getDistance();
    easyCam.setPosition(0, cameraHeightRatio*d, d*sqrt(1.0f-cameraHeightRatio*cameraHeightRatio));
    easyCam.setTarget(ofVec3f::zero());
}


//--------------------------------------------------------------
// Unused
//--------------------------------------------------------------
void ofApp::keyReleased(int key) {}
void ofApp::mouseMoved(int x, int y ) {}
void ofApp::mouseDragged(int x, int y, int button) {}
void ofApp::mousePressed(int x, int y, int button) {}
void ofApp::mouseReleased(int x, int y, int button) {}
void ofApp::mouseEntered(int x, int y) {}
void ofApp::mouseExited(int x, int y) {}
void ofApp::windowResized(int w, int h) {}
void ofApp::gotMessage(ofMessage msg) {}
void ofApp::dragEvent(ofDragInfo dragInfo) {}
